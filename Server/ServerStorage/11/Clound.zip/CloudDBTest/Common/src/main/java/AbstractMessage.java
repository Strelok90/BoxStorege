import java.io.Serializable;

public abstract class AbstractMessage implements Serializable {
}